#! /usr/local/bin/python

## CSC320 Winter 2017 
## Assignment 1
## (c) Kyros Kutulakos
##
## DISTRIBUTION OF THIS CODE ANY FORM (ELECTRONIC OR OTHERWISE)
## WITHOUT WRITTEN AUTHORIZATION OF THE INSTRUCTOR IS STRICTLY 
## PROHIBITED. VIOLATION OF THIS POLICY WILL BE CONSIDERED AN
## ACT OF ACADEMIC DISHONESTY

##
## DO NOT MODIFY ANY PART OF THIS FILE
##

import sys
from matting import run

if __name__ == '__main__':
    run.main(sys.argv)

