## CSC320 Winter 2019
## Assignment 1
## (c) Kyros Kutulakos
##
## DISTRIBUTION OF THIS CODE ANY FORM (ELECTRONIC OR OTHERWISE,
## AS-IS, MODIFIED OR IN PART), WITHOUT PRIOR WRITTEN AUTHORIZATION
## BY THE INSTRUCTOR IS STRICTLY PROHIBITED. VIOLATION OF THIS
## POLICY WILL BE CONSIDERED AN ACT OF ACADEMIC DISHONESTY

##
## DO NOT MODIFY THIS FILE ANYWHERE EXCEPT WHERE INDICATED
##

# import basic packages
import numpy as np
#import scipy.linalg as sp
import cv2 as cv

# If you wish to import any additional modules
# or define other utility functions,
# include them here

#########################################
## PLACE YOUR CODE BETWEEN THESE LINES ##
#########################################


#########################################

#
# The Matting Class
#
# This class contains all methods required for implementing
# triangulation matting and image compositing. Description of
# the individual methods is given below.
#
# To run triangulation matting you must create an instance
# of this class. See function run() in file run.py for an
# example of how it is called
#
class Matting:
    #
    # The class constructor
    #
    # When called, it creates a private dictionary object that acts as a container
    # for all input and all output images of the triangulation matting and compositing
    # algorithms. These images are initialized to None and populated/accessed by
    # calling the the readImage(), writeImage(), useTriangulationResults() methods.
    # See function run() in run.py for examples of their usage.
    #
    def __init__(self):
        self._images = {
            'backA': None,
            'backB': None,
            'compA': None,
            'compB': None,
            'colOut': None,
            'alphaOut': None,
            'backIn': None,
            'colIn': None,
            'alphaIn': None,
            'compOut': None,
        }

    # Return a dictionary containing the input arguments of the
    # triangulation matting algorithm, along with a brief explanation
    # and a default filename (or None)
    # This dictionary is used to create the command-line arguments
    # required by the algorithm. See the parseArguments() function
    # run.py for examples of its usage
    def mattingInput(self):
        return {
            'backA':{'msg':'Image filename for Background A Color','default':None},
            'backB':{'msg':'Image filename for Background B Color','default':None},
            'compA':{'msg':'Image filename for Composite A Color','default':None},
            'compB':{'msg':'Image filename for Composite B Color','default':None},
        }
    # Same as above, but for the output arguments
    def mattingOutput(self):
        return {
            'colOut':{'msg':'Image filename for Object Color','default':['color.tif']},
            'alphaOut':{'msg':'Image filename for Object Alpha','default':['alpha.tif']}
        }
    def compositingInput(self):
        return {
            'colIn':{'msg':'Image filename for Object Color','default':None},
            'alphaIn':{'msg':'Image filename for Object Alpha','default':None},
            'backIn':{'msg':'Image filename for Background Color','default':None},
        }
    def compositingOutput(self):
        return {
            'compOut':{'msg':'Image filename for Composite Color','default':['comp.tif']},
        }

    # Copy the output of the triangulation matting algorithm (i.e., the
    # object Color and object Alpha images) to the images holding the input
    # to the compositing algorithm. This way we can do compositing right after
    # triangulation matting without having to save the object Color and object
    # Alpha images to disk. This routine is NOT used for partA of the assignment.
    def useTriangulationResults(self):
        if (self._images['colOut'] is not None) and (self._images['alphaOut'] is not None):
            self._images['colIn'] = self._images['colOut'].copy()
            self._images['alphaIn'] = self._images['alphaOut'].copy()

    # If you wish to create additional methods for the
    # Matting class, include them here

    #########################################
    ## PLACE YOUR CODE BETWEEN THESE LINES ##
    #########################################

    #########################################

    # Use OpenCV to read an image from a file and copy its contents to the
    # matting instance's private dictionary object. The key
    # specifies the image variable and should be one of the
    # strings in lines 54-63. See run() in run.py for examples
    #
    # The routine should return True if it succeeded. If it did not, it should
    # leave the matting instance's dictionary entry unaffected and return
    # False, along with an error message
    def readImage(self, fileName, key):
        success = False
        msg = 'Placeholder'

        #########################################
        ## PLACE YOUR CODE BETWEEN THESE LINES ##
        #########################################
        img = cv.imread(fileName)/255.0
        msg = 'Image read failed'
        if not img is None:
            msg = "Success"
            self._images[key] = img
            success = True
        #########################################
        return success, msg

    # Use OpenCV to write to a file an image that is contained in the
    # instance's private dictionary. The key specifies the which image
    # should be written and should be one of the strings in lines 54-63.
    # See run() in run.py for usage examples
    #
    # The routine should return True if it succeeded. If it did not, it should
    # return False, along with an error message
    def writeImage(self, fileName, key):
        success = False
        msg = 'Placeholder'

        #########################################
        ## PLACE YOUR CODE BETWEEN THESE LINES ##
        ########################################
        success = cv.imwrite(fileName, (self._images[key]*255.0).astype(np.float32))
            #success = cv.imwrite(fileName, self._images[key].astype(np.uint16))
        if not success:
            msg = "Image write failed"
        #########################################
        return success, msg

    # Method implementing the triangulation matting algorithm. The
    # method takes its inputs/outputs from the method's private dictionary
    # ojbect.
    def triangulationMatting(self):
        """
success, errorMessage = triangulationMatting(self)

        Perform triangulation matting. Returns True if successful (ie.
        all inputs and outputs are valid) and False if not. When success=False
        an explanatory error message should be returned.
        """

        success = False
        msg = 'Placeholder'

        #########################################
        ## PLACE YOUR CODE BETWEEN THESE LINES ##
        #########################################
        c0, c1, b0, b1 = self._images['compA'], self._images['compB'], self._images['backA'], self._images['backB']
        if c0 is None or c1 is None or b0 is None or b1 is None:
            msg = "Couldn't retrieve photo data"
            return success, msg

        success = True
        msg = "Success"

        c0r, c0g, c0b = c0[:,:,0], c0[:,:,1], c0[:,:,2]
        c1r, c1g, c1b = c1[:,:,0], c1[:,:,1], c1[:,:,2]
        b0r, b0g, b0b = b0[:,:,0], b0[:,:,1], b0[:,:,2]
        b1r, b1g, b1b = b1[:,:,0], b1[:,:,1], b1[:,:,2]

        F = np.zeros((np.shape(c0r)[0], np.shape(c0r)[1], 4))
        for i in range(np.shape(c0r)[0]):
            for j in range(np.shape(c0r)[1]):
                C = np.array([c0r[i][j]-b0r[i][j], c0g[i][j]-b0g[i][j], c0b[i][j]-b0b[i][j], c1r[i][j]-b1r[i][j], c1g[i][j]-b1g[i][j], c1b[i][j]-b1b[i][j]])
                B = np.array([[1,0,0,-b0r[i][j]],[0,1,0,-b0g[i][j]],[0,0,1,-b0b[i][j]],[1,0,0,-b1r[i][j]],[0,1,0,-b1g[i][j]],[0,0,1,-b1b[i][j]]])
                F[i][j] = np.dot(np.linalg.pinv(B),C)

        F = np.clip(F, 0, 1)
        grayscale = np.zeros(np.shape(b0))
        grayscale[:,:,0], grayscale[:,:,1], grayscale[:,:,2] = F[:,:,3], F[:,:,3], F[:,:,3]
        
        self._images['colOut'] = F[:,:,0:3]
        self._images['alphaOut'] = grayscale
        #########################################

        return success, msg


    def createComposite(self):
        """
success, errorMessage = createComposite(self)

        Perform compositing. Returns True if successful (ie.
        all inputs and outputs are valid) and False if not. When success=False
        an explanatory error message should be returned.
"""

        success = False
        msg = 'Placeholder'

        #########################################
        ## PLACE YOUR CODE BETWEEN THESE LINES ##
        #########################################
        alphaIn = self._images['alphaIn']
        colIn = self._images['colIn']
        backIn = self._images['backIn']
        if alphaIn is None or colIn is None or backIn is None:
            msg = "Couldn't retrieve photo data"
            return success, msg

        success = True
        msg = "Success"
        blank = np.zeros(np.shape(alphaIn))

        for i in range(np.shape(alphaIn)[0]):
            for j in range(np.shape(alphaIn)[1]):
                blank[i][j] = (1.0 - alphaIn[i][j])*backIn[i][j]

        self._images['compOut'] = colIn + blank
        #########################################

        return success, msg
